﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Counter.Domain
{
    class Database
    {
    }
}
