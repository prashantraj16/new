﻿using System;

namespace Counter.Repository
{
    public class Class1
    {
    }
}
