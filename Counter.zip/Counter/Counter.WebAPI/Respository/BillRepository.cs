﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Counter.Domain.Entities;
using Counter.Domain.Repository;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Counter.WebAPI.Respository
{
    public class BillRepository : IBillRepository
    {
        private CounterDBContext context = null;
        private IMongoCollection<Bill> bills = null;

        public BillRepository(IOptions<Settings> settings)
        {
            this.context = new CounterDBContext(settings);
            bills = this.context.GetCollection<Bill>("Bill");
        }

        public async Task AddBill(Bill bill)
        {
            try
            {
                await bills.InsertOneAsync(bill);
            }
            catch (AggregateException aggEx)
            {
                aggEx.Handle(x =>
                {
                    var mwx = x as MongoWriteException;
                    if (mwx != null && mwx.WriteError.Category == ServerErrorCategory.DuplicateKey)
                    {
                        // mwx.WriteError.Message contains the duplicate key error message
                        return true;
                    }
                    return false;
                });
            }

        }

        public async Task<IEnumerable<Bill>> GetAllBills()
        {
            try
            {
                return await bills.Find(new BsonDocument()).ToListAsync<Bill>();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<Bill> GetBill(int billNumber)
        {
            try
            {
                return await bills.FindAsync<Bill>(bill => bill.BillNumber == billNumber).Result.FirstOrDefaultAsync<Bill>();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<DeleteResult> RemoveAll()
        {
            try
            {
                return await bills.DeleteManyAsync<Bill>(_ => true);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<DeleteResult> RemoveBill(int billNumber)
        {
            try
            {
                return await bills.DeleteOneAsync<Bill>(bill => bill.BillNumber == billNumber);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<bool> UpdateBill(Bill bill)
        {
            try
            {
                ReplaceOneResult replaceResult = await bills.ReplaceOneAsync<Bill>(b => b.BillNumber == bill.BillNumber, bill, new UpdateOptions() { IsUpsert = true });
                return replaceResult.ModifiedCount > 0 && replaceResult.IsAcknowledged;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public async Task<bool> AddItemToBill(int billNumber, Item item)
        {
            try
            {

                var filter = Builders<Bill>.Filter.Eq("BillNumber", billNumber);
                var update = Builders<Bill>.Update.Push("Items", item);
                var result = await bills.UpdateOneAsync(filter, update);
                return true;

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
