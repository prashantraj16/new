﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Counter.Domain.Entities;
using Counter.Domain.Repository;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Counter.WebAPI.Respository
{
    public class ProductRepository : IProductRepository
    {
        private readonly CounterDBContext context = null;
        private IMongoCollection<Product> products = null;
        public ProductRepository(IOptions<Settings> settings)
        {
            context = new CounterDBContext(settings);
            products = context.GetCollection<Product>("Product");
        }

        public async Task AddProduct(Product product)
        {
            try
            {
                 await products.InsertOneAsync(product);
                
            }
            catch (AggregateException aggEx)
            {
                aggEx.Handle(x =>
                {
                    var mwx = x as MongoWriteException;
                    if (mwx != null && mwx.WriteError.Category == ServerErrorCategory.DuplicateKey)
                    {
                        // mwx.WriteError.Message contains the duplicate key error message
                        return true;
                    }
                    return false;
                });
            }
        }

        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            return await products.Find(new BsonDocument()).ToListAsync();
        }

        public async Task<Product> GetProduct(int productId)
        {
            try
            {
                var value = products.FindAsync(x => x.ProductId == productId).Result.FirstOrDefaultAsync<Product>();
                return await value;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<IEnumerable<Product>> GetProducts(string searchByName)
        {
            try
            {
                return await products.FindAsync(x => x.ProductName.ToLower().Contains(searchByName.ToLower())).Result.ToListAsync<Product>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
