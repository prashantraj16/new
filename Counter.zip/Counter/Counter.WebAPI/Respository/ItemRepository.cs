﻿using Counter.Domain.Entities;
using Counter.Domain.Repository;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Counter.WebAPI.Respository
{
    public class ItemRepository : IItemRepository
    {
        private readonly CounterDBContext context = null;
        private IMongoCollection<Item> items = null;
        public ItemRepository(IOptions<Settings> settings)
        {
            context = new CounterDBContext(settings);
            items = context.GetCollection<Item>("Item");
        }

        public async Task AddItem(Item item)
        {
            try
            {
                await items.InsertOneAsync(item);
            }
            catch (AggregateException aggEx)
            {
                aggEx.Handle(x =>
                {
                    var mwx = x as MongoWriteException;
                    if (mwx != null && mwx.WriteError.Category == ServerErrorCategory.DuplicateKey)
                    {
                        // mwx.WriteError.Message contains the duplicate key error message
                        return true;
                    }
                    return false;
                });
            }

        }

        public async Task<IEnumerable<Item>> GetallItems(int billNo)
        {
            try
            {
                return await items.Find(new BsonDocument()).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<Item> GetItem(int itemId)
        {
            try
            {
                return await items.FindAsync(item => item.ItemId == itemId).Result.FirstOrDefaultAsync<Item>();
            }
            catch (Exception)
            {

                throw;
            }   
        }
      
        public async Task<DeleteResult> RemoveAllItems(int billNumber)
        {
            try
            {
                return await items.DeleteManyAsync<Item>(item => item.BillNumber == billNumber);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<DeleteResult> RemoveItem(int billNumber, int itemId)
        {
            try
            {                
                return await items.DeleteOneAsync<Item>(item => item.BillNumber == billNumber);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> UpdateItem(Item item)
        {
            try
            {
                //var filter = Builders<Item>.Filter.Eq(s => s.ItemId, item.ItemId);

                //var update = Builders<Item>.Update.Set(s => s.body)

                ReplaceOneResult actionResult = await items.ReplaceOneAsync<Item>(n => n.ItemId == item.ItemId, item, new UpdateOptions { IsUpsert = true });
                return actionResult.IsAcknowledged && actionResult.ModifiedCount > 0;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
