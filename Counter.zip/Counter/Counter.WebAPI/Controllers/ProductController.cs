﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Counter.Domain.Entities;
using Counter.Domain.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;

namespace Counter.WebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository productRepository;

        public ProductController(IProductRepository productRepo)
        {
            productRepository = productRepo;
        }

        [HttpGet]
        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            return await productRepository.GetAllProducts();
        }

        [HttpGet("{name}")]
        public async Task<IEnumerable<Product>> GetProducts(string name)
        {
            return await productRepository.GetProducts(name);
        }

        [HttpGet("GetProduct/{id:int}")]        
        public async Task<Product> GetProduct(int id)
        {
            return await productRepository.GetProduct(id);
        }

        [HttpPost]
        public async Task<bool> AddProduct(Product product)
        {
            try
            {
                await productRepository.AddProduct(product);
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}