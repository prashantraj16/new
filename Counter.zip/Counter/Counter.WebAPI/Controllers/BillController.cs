﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Counter.Domain.Entities;
using Counter.Domain.Repository;
using Counter.WebAPI.Respository;
using Microsoft.AspNetCore.Mvc;

namespace Counter.WebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/bill")]
    [ApiController]
    public class BillController : Controller
    {
        private IBillRepository billRepository = null;

        public BillController(IBillRepository billRepos)
        {
            billRepository = billRepos;
        }

        [HttpGet]
        public async Task<ActionResult<Bill>> GetBills()
        {
            try
            {
                var bills = await billRepository.GetAllBills();
                return Ok(bills);
            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost]
        public async Task<ActionResult<bool>> AddBill(Bill bill)
        {
            try
            {
                await billRepository.AddBill(bill);
                return Ok(true);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPut]
        public async Task<ActionResult<bool>> AddItemToBill(int billNumber, Item item)
        {
            try
            {
                var x = await billRepository.AddItemToBill(billNumber, item);
                return Ok(x);
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}