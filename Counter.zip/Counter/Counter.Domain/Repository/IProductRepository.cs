﻿using Counter.Domain.Entities;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Domain.Repository
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetAllProducts();

        Task<IEnumerable<Product>> GetProducts(string searchByName);

        Task<Product> GetProduct(int productId);

        Task AddProduct(Product product);
    }
}
