﻿using Counter.Domain.Entities;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Domain.Repository
{
    public interface IItemRepository
    {
        Task<IEnumerable<Item>> GetallItems(int billNo);

        Task<Item> GetItem(int id);

        Task<DeleteResult> RemoveItem(int billNumber, int itemId);


        Task<DeleteResult> RemoveAllItems(int billNumber);

        Task AddItem(Item item);

        Task<bool> UpdateItem(Item item);

    }
}
