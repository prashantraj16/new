﻿using Counter.Domain.Entities;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Domain.Repository
{
    public interface IBillRepository
    {
        Task<IEnumerable<Bill>> GetAllBills();

        Task<Bill> GetBill(int id);

        Task AddBill(Bill bill);

        Task<bool> UpdateBill(Bill bill);

        Task<DeleteResult> RemoveAll();

        Task<DeleteResult> RemoveBill(int id);

        Task<bool> AddItemToBill(int billNumber, Item item);
    }
}
