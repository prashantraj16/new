﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Counter.Domain.Entities
{
    public class Item
    {
        [BsonId]
        public ObjectId Id { get; set; }

        public int ItemId { get; set; }

        public int ProductId { get; set; }

        public decimal TaxLevied { get; set; }

        public int Quantity { get; set; }

        public decimal ItemPrice { get;                
            set;                           
        }

        public decimal TotalPrice
        {
            get;
                //return this.totalPrice;

            set;
            
                //value = this.ItemPrice + ItemPrice * int.Parse(this.Products.First().Category.ToString()) / 100;
            
        }

        public int BillNumber { get; set; }
    }
}
