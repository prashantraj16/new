﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Counter.Domain.Entities
{
    public class Bill
    {

        [BsonId]
        public ObjectId Id { get; set; }

        public int BillNumber { get; set; }

        public decimal TotalTax { get; set; }

        public int TotalQuantity { get; set; }

        public decimal ItemAmount { get; set; }

        public decimal BillAmount { get; set; }

        public List<Item> Items { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CustomerName { get; set; }

        public string CustomerPhoneNumber { get; set; }
    }
}
