﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Counter.Domain.Entities
{
    public class SalesTax
    {

    }
}
