﻿using System;
using System.Collections.Generic;
using System.Text;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Counter.Domain.Entities
{
    public class Product
    {

        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("ProductId")]
        public int ProductId   { get; set; }        

        [BsonElement("ProductName")]
        public string ProductName { get; set; }

        [BsonElement("ProductPrice")]
        public decimal ProductPrice { get; set; }

        [BsonElement("Category")]
        public TaxCategory Category { get; set; }
    }
}
