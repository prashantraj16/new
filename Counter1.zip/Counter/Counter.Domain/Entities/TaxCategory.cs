﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Counter.Domain.Entities
{
    public enum TaxCategory
    {
        CategoryA = 10,
        CategoryB = 20,
        CategoryC = 0
    }
}
