﻿using Counter.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Counter.Domain.Service
{
    public interface IUserService
    {
        User Authenticate(string userName, string password);

        IEnumerable<User> GetAllUsers();

        Task<User> Register(User user);
    }
}
