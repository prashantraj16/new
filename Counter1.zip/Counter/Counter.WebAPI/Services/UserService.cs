﻿using Counter.Domain.Entities;
using Counter.Domain.Repository;
using Counter.Domain.Service;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Counter.WebAPI.Services
{
    public class UserService : IUserService
    {
        private IUserRepository _userRepository = null;
        private readonly AppSettings _appSettings = null;
        public UserService(IUserRepository userRepository, IOptions<AppSettings> appSettings)
        {
            _userRepository = userRepository;
            _appSettings = appSettings.Value;
        }

        public User Authenticate(string userName, string password)
        {
            var users =  _userRepository.GetAllUsers();
            var user = users.ToList<User>().FirstOrDefault(x => x.Username.ToLower() == userName.ToLower() && x.Password.ToLower() == password.ToLower());
            if (user == null)
                return null;

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                   new Claim(ClaimTypes.Name, userName)
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256)
            };
            IdentityModelEventSource.ShowPII = true;

            var token = tokenHandler.CreateToken(tokenDescriptor);

            user.token = tokenHandler.WriteToken(token);
            user.Password = null;

            return user;
        }

        public IEnumerable<User> GetAllUsers()
        {
            return  _userRepository.GetAllUsers();    
        }

        public async Task<User> Register(User user)
        {
            try
            {
                return await _userRepository.Register(user);
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
