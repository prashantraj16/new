﻿using Counter.Domain.Entities;
using Counter.Domain.Repository;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Counter.WebAPI.Respository
{
    public class UserRepository : IUserRepository
    {
        private CounterDBContext context = null;
        private IMongoCollection<User> users = null;

        public UserRepository(IOptions<Settings> settings)
        {
            context = new CounterDBContext(settings);
            users = context.GetCollection<User>("User");
        }

        public IEnumerable<User> GetAllUsers()
        {
            try
            {

                return users.Find(new BsonDocument()).ToList<User>();
               
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public async Task<User> Register(User user)
        {
            try
            {
                await users.InsertOneAsync(user);
                return user;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
