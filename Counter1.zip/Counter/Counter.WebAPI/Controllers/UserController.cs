﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Counter.WebAPI.Services;
using Counter.Domain.Entities;
using Counter.Domain.Service;

namespace Counter.WebAPI.Controllers
{
    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : Controller
    {
        private IUserService _userServices = null;
        public UserController(IUserService userServices)
        {
            _userServices = userServices;
        }


        [AllowAnonymous]
        [HttpPost("register")]        
        public IActionResult Register([FromBody] User user)
        {
            var _user = _userServices.Register(user);

            return Ok(_user);
        }

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public ActionResult Authenticate([FromBody] User user)// string username, [FromBody] string password)
        {
            var _user = _userServices.Authenticate(user.Username, user.Password);

            if (_user == null)
                return BadRequest(new { Message =  "User Not Authorized." });

            return Ok(_user);            
        }
       
        [HttpGet]
        public ActionResult GetUser()
        {
            try
            {
                var allUsers =  _userServices.GetAllUsers();
                return Ok(allUsers);
            }
            catch (Exception ex)
            {

                throw;
            }

           
        }


    }
}